package com.example.emqtest

/**
 *@author : Administrator
 *@descreption :
 */
interface MainView {
}