package com.example.emqtest

/**
 *@author : Administrator
 *@descreption : 常量
 */
object Constant {
    val BASE_URL = "http://182.254.221.70:1883/"
}