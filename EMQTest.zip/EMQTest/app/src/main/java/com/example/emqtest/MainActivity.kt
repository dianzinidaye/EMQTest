package com.example.emqtest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.Callback
import okhttp3.ResponseBody

import retrofit2.Call
import retrofit2.Response

class MainActivity : AppCompatActivity(),MainView {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        MyMqttService.startService(this) //开启服务
/*        val present = MainPresent<MainActivity>()
        present.bindView(this)
        val map  = HashMap<String,String>()
        map.apply {
           // put("content-type","x-www-form-urlencoded")
            put("clientid","MQTT_FX_Client")
          //  put("password","hu736821956")
           // put("%p","1883")
            //put("%a","182.254.221.70")
        }*/
/*        login.setOnClickListener {
          val result =   present.login(map)
                    result.enqueue(object : retrofit2.Callback<Any> {
                        override fun onResponse(
                            call: Call<Any>,
                            response: Response<Any>
                        ) {
                            Log.i("TAG", "成功 ");
                        }

                        override fun onFailure(call: Call<Any>, t: Throwable) {
                            Log.i("TAG", ":失败 ");
                        }
                    })


        }*/
    }
}